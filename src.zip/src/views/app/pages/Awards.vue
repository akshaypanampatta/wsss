<template>
<div>
    <Navbar />
    <div class="aswards">
        <div class="awards-header">
            <h1>Awards & Recognitions</h1>
        </div>
        <div class="awards-body">
            <div class="awars-list">
                <div class="one-award">
                    <div class="one-award-left">
                        <img src="/images/award.png" alt="">
                    </div>
                    <div class="award-text">
                        <div class="d-flex align-items-center " style="gap: 1.5rem;">
                            <img class="badgee" src="/images/badge2.png" alt="">
                            <h3>SPECIAL APPRECIATION AWARD - 2019</h3>
                        </div>
                        <div>
                            <p>WSSS got Special Appreciation award from World Malayalee Association for Environment Conservation Projects. Mr.Pradeep Kumar, WSSS received the Special Appreciation Award from Sri. Pinarai Vijayan, Chief Minister of Kerala</p>
                        </div>
                    </div>
                </div>
                <div class="one-award">
                    <div class="award-text">
                        <div class="d-flex align-items-center " style="gap: 1.5rem;">
                            <img class="badgee" src="/images/badge2.png" alt="">
                            <h3>BEST PFA (NABARD WADI PROJCET)</h3>
                        </div>
                        <div>
                            <p>Wayanad Social Service Society has been selected as the best Program Facilitating Agency in the State for NABARD Integrated Tribal Development Project (WADI). During the function held at Thiruvanathapuram, Rev.Fr. Jinoj Palathadathil (Associate Director, WSSS) and P.A.Jose (Program Officer, WSSS) were accepted Award from Sri.V.S.Anilkumar, Minister for Agriculture, Kerala State. NABARD is implementing the Integrated Tribal Development Project (WADI) in various districts of Kerala. The project is being implemented by various Program Facilitating Agencies (PFAs).</p>
                        </div>
                    </div>
                    <div class="one-award-left">
                        <img src="/images/award2.png" alt="">
                    </div>

                </div>
                <div class="one-award">
                    <div class="one-award-left">
                        <img src="/images/award3.png" alt="">
                    </div>
                    <div class="award-text">
                        <div class="d-flex align-items-center" style="gap: 1.5rem;">
                            <img class="badgee" src="/images/badge2.png" alt="">
                            <h3>SPECIAL CONSULTATIVE STATUS FOR WSSS WITH THE UNITED NATIONS ECONOMIC AND SOCIAL COUNCIL (ECOSOC)</h3>
                        </div>
                        <div>
                            <p>Wayanad Social Service Society has been selected as the best Program Facilitating Agency in the State for NABARD Integrated Tribal Development Project (WADI). During the function held at Thiruvanathapuram, Rev.Fr. Jinoj Palathadathil (Associate Director, WSSS) and P.A.Jose (Program Officer, WSSS) were accepted Award from Sri.V.S.Anilkumar, Minister for Agriculture, Kerala State. NABARD is implementing the Integrated Tribal Development Project (WADI) in various districts of Kerala. The project is being implemented by various Program Facilitating Agencies (PFAs).
                            </p>
                        </div>
                    </div>
                </div>
                <div class="one-award">
                    <div class="award-text">
                        <div class="d-flex align-items-center " style="gap: 1.5rem;">
                            <img class="badgee" src="/images/badge2.png" alt="">
                            <h3>Paristhithi Mithra Award, Uzhavoor College</h3>
                        </div>
                        <div>
                            <p>Paristhithi Mithra is an award instituted by the CEERD, St. Stephen’s College, Uzhavoor every year on June 5th Environment Day. The award is given in recognition of the outstanding contribution towards the promotion of environmental protection, conservation and preservation in the State of Kerala. On this special day Mr.P.A.Jose, Program Officer, WSSS received the Paristhithi Mitra Award  from Sri. Mons Joseph MLA at St. Stephen College, Uzhavoor for raising the awareness level and encouraging positive actions for the environment, galvanizing individual actions into a collective power that generates an exponential positive impact. The award marks the importance of World Environment Day on 5 June and celebrates innovative and outstanding environmental programs and initiatives in and around Kerala, as well as the critical work of environmental leaders.</p>
                        </div>
                    </div>
                    <div class="one-award-left">
                        <img src="/images/award4.png" alt="">
                    </div>

                </div>
                <div class="d-flex" style="gap: 3.375rem;border-bottom: solid 1px #d1d1d1;">
                    <div class="d-flex w-50 flex-column" style="padding: 3.375rem 0;gap: 0.75rem;">
                        <img style="max-height: 21rem;" src="/images/award5.png" alt="">
                        <div class="d-flex align-items-center" style="gap: 1.6875rem;">
                            <img  class="badgee" src="/images/badge2.png" alt="">
                            <h3 style="font-weight: 400;font-size: 1.5rem;color: #000;">Excellence Award: Kerala Social Service Form- 2014</h3>
                        </div>
                    </div>
                    <div class="d-flex w-50 flex-column" style="padding: 3.375rem 0;gap: 0.75rem;">
                          <img style="max-height: 21rem;" src="/images/award6.png" alt="">
                        <div class="d-flex align-items-center" style="gap: 1.6875rem;">
                            <img  class="badgee" src="/images/badge2.png" alt="">
                            <h3 style="font-weight: 400;font-size: 1.5rem;color: #000;">Best overall performance of State Nodal Agency ( first prize) : Vikaspedia- 2016</h3>
                        </div>
                    </div>
                    <!-- <div class="one-award flex-column">
                        <div class="one-award-left">
                            <img src="/images/award5.png" alt="">
                        </div>
                        <div class="award-text">
                            <div class="d-flex align-items-center" style="gap: 1.5rem;">
                                <img class="badgee" src="/images/badge2.png" alt="">
                                <h3>Excellence Award: Kerala Social Service Form- 2014</h3>
                            </div>
                            <div>
                                <p>To text</p>
                            </div>
                        </div>
                    </div>
                    <div class="one-award">
                        <div class="award-text">
                            <div class="d-flex align-items-center " style="gap: 1.5rem;">
                                <img class="badgee" src="/images/badge2.png" alt="">
                                <h3>Best overall performance of State Nodal Agency ( first prize) : Vikaspedia- 2016</h3>
                            </div>
                            <div>
                                <p>No text</p>
                            </div>
                        </div>
                        <div class="one-award-left">
                            <img src="/images/award6.png" alt="">
                        </div>

                    </div> -->
                </div>

            </div>
            <div style="padding: 2.625rem 0;margin-top: 2rem;">
                <h1 style="font-size: 3.5625rem;font-weight: 400;color: #000;">Recognitions</h1>
            </div>
            <div v-for="(award,index) in awards" class="other-awards py-4 d-flex align-items-center">
                <img src="/images/badge2.png" alt="">
                <p>{{ award.name }}</p>
            </div>
            <!-- <div style="padding: 2.625rem 0;margin-top: 3.4rem;">
                <h1 style="font-size: 3.5625rem;font-weight: 400;color: #000;">Recognitions</h1>
            </div>
            <div class="d-flex flex-wrap" style="gap: 0.5rem;">
                <div v-for="recognition in Recognitions " class="recognition-one">
                    <div class="d-flex flex-column" style="z-index: 1000!important;gap: 1.5rem;">
                        <p>THE RECOGNISATION</p>
                        <h1>{{ recognition.text }}</h1>
                        <img  src="/images/awards.png" alt="">
                    </div>
                </div>
            </div> -->
        </div>
    </div>

    <Footer />

</div>
</template>

<script>
import Navbar from './components/Navbar.vue';
import Footer from './components/Footer.vue';

export default {
    name: "Awards",
    data() {
        return {
            awards: [{
                    name: 'Regional Council For Pgs- Ncof-govt. Of India',
                },
                {
                    name:'Service Provider for Organic Farming: NCOF-Govt. of India'
                },
                 {
                    name:'State Nodal Agency For Vikaspedia Knowledge Portal – Ministry Of Information Technology '
                },
                 {
                    name:'Program Facilitating Agency for NABARD Women SHG Program, Watershed Program, WADI Program, Farm Club Promotion, JLG Promotion, MEDP, LEDP, CAT, Financial Literacy , FTTF, UPNRM Project, Farmer Producer Organizations & KfW Soil projects.'
                },
                 {
                    name:'Program Facilitating Agency of TRIFED'
                },
                 {
                    name:'Service Provider of Tribal Sub Plan Projects'
                },
                 {
                    name:'Program Implementing Agency of NAI ROSHNI Training Program- Ministry of Rural Development'
                },
                 {
                    name:'Program Facilitating Agency of Sammunnathi Project- Corporation for Forward Community.'
                },
                 {
                    name:'Program Implementing Agency of NULM- Ministry of Rural Development'
                },
                 {
                    name:'Program Implementing Agency of Western Ghat Development Projects- Department of Planning & Economic Affairs.'
                },
                 {
                    name:'Service Provider of Sujitwa Mission Kerala'
                },
                 {
                    name:'Supporting Organization of Jalanidhi Project'
                },
                 {
                    name:'Program Implementing Agency- FCT Training, Coconut Dev. Board'
                },
                 {
                    name:'Service Provider of MILMA for Biogas Promotion'
                },
                 {
                    name:'Service Provider of Sustainable Development Agency – SDA'
                },
                 {
                    name:'Service Provider of Andhyodaya - Solar Water Heater, CFL Lamps, Lanterns & DLS'
                },
                 {
                    name:'Service Provider of Khadi & Village Industries Commission'
                },
                 {
                    name:'Master Training Institute for NABARD Krishi Jaldhooth Project'
                },
                 {
                    name:'National Accredited Agency for conducting NABARD rural immersion program'
                },
                 {
                    name:'Consortium Partner for ICAR Projects'
                },
                

               

            ],
            Recognitions: [{
                    text: 'Regional Council for PGS- NCOF-Govt. of India'
                },
                {
                    text: 'Service Provider for Organic Farming: NCOF-Govt. of India'
                },
                {
                    text: 'State Nodal Agency for Vikaspedia knowledge portal – Ministry of Information technology'
                },
                {
                    text: 'Program Facilitating Agency for NABARD Women SHG Program, Watershed Program, WADI Program, Farm Club Promotion, JLG Promotion, MEDP, LEDP, CAT, Financial Literacy , FTTF, UPNRM Project, Farmer Producer Organizations & KfW Soil projects.'
                },
                {
                    text: 'Program Implementing Agency of Western Ghat Development Projects- Department of Planning & Economic Affairs.'
                },
                {
                    text: 'Program Implementing Agency of NULM- Ministry of Rural Development'
                },
                {
                    text: 'Program Implementing Agency of NAI ROSHNI Training Program- Ministry of Rural Development'
                },
                {
                    text: 'Program Facilitating Agency of Sammunnathi Project- Corporation for Forward Community.'
                },
                {
                    text: 'Service Provider of Tribal Sub Plan Projects'
                },
                {
                    text: 'Program Facilitating Agency of TRIFED'
                },

                {
                    text: 'Service Provider of Sujitwa Mission Kerala'
                },
                {
                    text: 'Supporting Organization of Jalanidhi Project'
                },
                {
                    text: 'Program Implementing Agency- FCT Training, Coconut Dev. Board'
                },
                {
                    text: 'Service Provider of MILMA for Biogas Promotion'
                },
                {
                    text: 'Service Provider of Sustainable Development Agency – SDA'
                },
                {
                    text: 'Service Provider of Andhyodaya - Solar Water Heater, CFL Lamps, Lanterns & DLS'
                },
                {
                    text: 'Service Provider of Khadi & Village Industries Commission'
                },
                {
                    text: 'Master Training Institute for NABARD Krishi Jaldhooth Project'
                },
                {
                    text: 'National Accredited Agency for conducting NABARD rural immersion program'
                },
                {
                    text: 'Consortium Partner for ICAR Projects'
                },

            ]
        }
    },
    components: {
        Navbar,
        Footer
    }
}
</script>

<style>
@import "./style/style.css";
</style>
