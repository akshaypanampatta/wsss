
<template>
  <div>
    <header style="background-color: gray;">
      <img src="/images/logo1.png" style="height: 50px;">
    </header>
  </div>
</template>
<script>

</script>
<style scoped>

@import './style/style.css';
  
</style>

