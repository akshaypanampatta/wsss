<template>
<div>
    <h1>fedf</h1>
    <h2>gwdlkhjfgwlojhfjhvjls</h2>
</div>
</template>

<script>
export default {
    name: "header"

};
</script>

<style>
@import '../style/style.css';
</style>
