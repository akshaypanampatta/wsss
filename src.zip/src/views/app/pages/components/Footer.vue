<template>
<div class="footerr">
    <div class="footer-top">
        <div class="footer-top-left">
            <h1>Get in touch</h1>
            <p class="">Wayanad Social Service Society (WSSS) is a registered charitable society and a secular voluntary organization established in the year 1974. It is the official social service organization of the Catholic Diocese of Mananthavady.</p>
        </div>
        <div class="footer-top-right">
            <h2>Address</h2>
            <p>WSSS P.B.No.16,</p>
            <p>Mananthavady-670645, </p>
            <p>Wayanad,Kerala,India</p>
        </div>

    </div>
    <div class="footer-btm">
        <div class="footer-btm-left">
            <img class="footer-logo" src="/images/footer-logo.png" alt="">
            <div class="d-flex flex-column" style="gap: 1.3rem;">
                <h1>Would you like to speak to us? We’re listening.</h1>
                <button class="contact-btn">Contact us <img src="/images/arrow.svg" alt=""></button>
            </div>
        </div>
        <div class="footer-btm-right">
            <h6>Privacy and policy • Terms and conditions</h6>
            <p>Copyright 2023 WSSS LTD. All rights reserved.</p>
            <div class="social-media">
                <img src="/images/linkedin.svg" alt="">
                <img src="/images/facebook.svg" alt="">
                <img src="/images/instagram.svg" alt="">
                <img src="/images/twitter.svg" alt="">
            </div>

        </div>
        <div>

        </div>

    </div>

</div>
</template>

<script>
export default {
    name: "Footer"
}
</script>

<style scoped>
@import "../style/style.css";
</style>
