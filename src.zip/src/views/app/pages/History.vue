<template >
    <div>
        <Navbar/>
        <div class="mt-3" style=" padding: 2.625rem 4.5rem 1.5rem 4.5rem;border-bottom: solid 1px #d1d1d1;">
            <h1 style="font-weight: 400;font-size: 3.5625rem;color: #000;">History</h1>
        </div>
        <div class="d-flex flex-column" style="padding: 0 4.5rem;">
            div

        </div>
        
    </div>
</template>
<script>
import Navbar from './components/Navbar.vue';

export default {
    name: 'History',
    components: { Navbar }
}
</script>
<style >
@import "./style/style.css";
    
</style>