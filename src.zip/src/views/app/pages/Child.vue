<template>
    <h1>Child component</h1>
</template>
<script>
export default{
    name:"Child"
}

</script>